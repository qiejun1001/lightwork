package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.ContentObservable;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.UserHandle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    private MyDatabaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        initWidget();

        dbHelper=new MyDatabaseHelper(
                this,
                "UserStore.db",
                null,
                1);
        Button createDatabase=(Button)findViewById(R.id.button5);
        final EditText editText3=(EditText)findViewById(R.id.editText3) ;
        final EditText editText4=(EditText)findViewById(R.id.editText4) ;
        final EditText editText5=(EditText)findViewById(R.id.editText5) ;
        createDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.getWritableDatabase();
                String phone=editText3.getText().toString();
                String name=editText4.getText().toString();
                String password=editText5.getText().toString();
                if (phone.equals("")||name.equals("")||password.equals("")){
                    Toast.makeText(Main2Activity.this,"请填将资料写完整",Toast.LENGTH_SHORT).show();
                }else{
                    insertData(  dbHelper.getWritableDatabase(),phone,name,password);
                    Toast.makeText(Main2Activity.this,"保存成功",Toast.LENGTH_SHORT).show();

                }
            }
        });



    }
    private void initWidget(){
        Button btn=(Button)findViewById(R.id.button3);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent=new Intent(Main2Activity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
    private void insertData(SQLiteDatabase sqLiteDatabase,String phone,String name,String password){
         ContentValues values=new ContentValues();
         values.put("phone",phone);
        values.put("name",name);
        values.put("password",password);
        sqLiteDatabase.insert("User",null,values);
    }
}
