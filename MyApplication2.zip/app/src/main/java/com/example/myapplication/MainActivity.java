package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Looper;
import android.telecom.Call;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ForkJoinTask;

public class MainActivity extends AppCompatActivity {

    private MyDatabaseHelper dbHelper;
    private EditText usm;   //账户
    private EditText pass;  //密码
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initWidget();
        dbHelper=new MyDatabaseHelper(
                this,
                "UserStore.db",
                null,
                1);
        usm = (EditText)findViewById(R.id.editText);
        pass= (EditText)findViewById(R.id.editText2);
    }


    private void initWidget(){
        Button btn=(Button)findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,Main2Activity.class);
                startActivity(intent);
            }
        });
        String platformAddress = "http://api.nlecloud.com:80/";
        final String _username = usm.getText().toString();// "17674738454";
        final String _password = pass.getText().toString();//"123456";
        final EditText editText=(EditText)findViewById(R.id.editText) ;
        final EditText editText2=(EditText)findViewById(R.id.editText2) ;
        Button btn2=(Button)findViewById(R.id.button);
        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final String name = editText.getText().toString();
                final String password = editText2.getText().toString();
                Cursor cursor = dbHelper.getReadableDatabase().query("User", null, "name=?", new String[]{name}, null, null, null);
                String username;
                String psd=null;
                ArrayList<Map<String, String>> resultList1 = new ArrayList<Map<String, String>>();



                while (cursor.moveToNext()) {
                    Map<String,String> map = new HashMap<String, String>();
                    map.put("name", cursor.getString(2));
                    map.put("password", cursor.getString(3));
                    Object get2=map.get("password");
                    psd=(String)get2;
                    resultList1.add(map);

                }
                if (name.equals("") || password.equals("")) {
                    Toast.makeText(MainActivity.this, "请填将资料写完整", Toast.LENGTH_SHORT).show();
                } else if (resultList1 == null || resultList1.size() == 0) {
                    Toast.makeText(MainActivity.this, "未查询到该账户", Toast.LENGTH_SHORT).show();
                } else if (password.equals(psd)) {
                    Toast.makeText(MainActivity.this, "登陆成功", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, Main3Activity.class);
                    startActivity(intent);

                }
                else {
                    Toast.makeText(MainActivity.this,"密码错误",Toast.LENGTH_SHORT).show();
                }
            }

        });


    }


}
