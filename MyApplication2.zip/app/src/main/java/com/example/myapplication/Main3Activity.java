package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        initWidget();
        Button btn=(Button)findViewById(R.id.light_on_off);
        final ImageView imageView3=(ImageView) findViewById(R.id.imageView3);
        final ImageView imageView14=(ImageView) findViewById(R.id.imageView14);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imageView14.getVisibility()==View.VISIBLE){
                    imageView14.setVisibility(View.INVISIBLE);
                    imageView3.setVisibility(View.VISIBLE);
                }else{
                    imageView3.setVisibility(View.INVISIBLE);
                    imageView14.setVisibility(View.VISIBLE);
                }
            }
        });
    }
    private void initWidget(){
        Button btn=(Button)findViewById(R.id.button4);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent=new Intent(Main3Activity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }


}
